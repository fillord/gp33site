import json
import logging
import pandas as pd
import os
import uuid

from sqlalchemy import select, delete, update as sql_update
from database import async_session
from models import News, Video, Review, Schedule, Vacancy
from dotenv import load_dotenv
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, 
    ContextTypes, 
    CommandHandler, 
    MessageHandler, 
    filters, 
    ConversationHandler, 
    CallbackQueryHandler,
    Defaults
)
from telegram.constants import ParseMode

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Теперь достаем их через os.getenv
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID")
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")

if not BOT_TOKEN:
    print("Ошибка: BOT_TOKEN не найден в .env файле!")

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# === СОСТОЯНИЯ ===
CHOOSING_ACTION = 0
NEWS_TITLE_RU = 1
NEWS_TITLE_KZ = 2
NEWS_TEXT_RU = 3
NEWS_TEXT_KZ = 4
NEWS_PHOTO = 5   
VIDEO_TITLE_RU = 6
VIDEO_TITLE_KZ = 7
VIDEO_URL = 8
WAITING_SCHEDULE = 9
WAITING_VACANCY_TITLE, WAITING_VACANCY_SALARY, WAITING_VACANCY_TEXT = range(10, 13)


# === КЛАВИАТУРЫ ===
MAIN_MENU_MARKUP = ReplyKeyboardMarkup([
    ["📅 Обновить график"],  # <--- НОВАЯ КНОПКА
    ["📰 Добавить новость", "🎥 Добавить видео"],
    ["📋 Список новостей", "📋 Список видео"],
    ["📋 Список вакансий", "💼 Вакансии (Добавить)"],
    ["💬 Список отзывов"]
], resize_keyboard=True)

CANCEL_MARKUP = ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
PHOTO_MARKUP = ReplyKeyboardMarkup([["⏭ Пропустить фото"], ["❌ Отмена"]], resize_keyboard=True)

# === БАЗА ДАННЫХ ===


# === СТАРТ И ОТМЕНА ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Проверка прав
    if str(update.effective_chat.id) != str(ADMIN_CHAT_ID):
        await update.message.reply_text("⛔ Доступ запрещен.")
        return ConversationHandler.END
    
    # Сброс данных при рестарте
    context.user_data.clear()
    await update.message.reply_text("👋 Привет, Админ! Меню готово.", reply_markup=MAIN_MENU_MARKUP)
    return CHOOSING_ACTION

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("❌ Действие отменено.", reply_markup=MAIN_MENU_MARKUP)
    return CHOOSING_ACTION

# === ВЫБОР ДЕЙСТВИЯ ===
async def choose_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    
    if text == "📰 Добавить новость":
        await update.message.reply_text("🇷🇺 Шаг 1/5: Введите заголовок (RU):", reply_markup=CANCEL_MARKUP)
        return NEWS_TITLE_RU
    elif text == "📅 Обновить график":
        await update.message.reply_text(
            "📤 Отправьте мне **Excel-файл (.xlsx)** с графиком.\n\n"
            "Убедитесь, что заголовки: ФИО, Должность, Кабинет, ПН, ВТ, СР, ЧТ, ПТ.",
            parse_mode="Markdown",
            reply_markup=CANCEL_MARKUP
        )
        return WAITING_SCHEDULE
    
    elif text == "🎥 Добавить видео":
        await update.message.reply_text("🇷🇺 Шаг 1/3: Введите название видео (RU):", reply_markup=CANCEL_MARKUP)
        return VIDEO_TITLE_RU
        
    elif text == "💬 Список отзывов":
        await show_list(update, "reviews", "Отзывы")
        return CHOOSING_ACTION
    elif text == "📋 Список новостей":
        await show_list(update, "news", "Новости")
        return CHOOSING_ACTION
    elif text == "📋 Список видео":
        await show_list(update, "videos", "Видео")
        return CHOOSING_ACTION
        
    else:
        await update.message.reply_text("Используйте кнопки меню.", reply_markup=MAIN_MENU_MARKUP)
        return CHOOSING_ACTION

# === НОВОСТИ (ШАГИ) ===
async def news_title_ru(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['n_title_ru'] = update.message.text
    await update.message.reply_text("🇰🇿 Шаг 2/5: Заголовок (KZ):", reply_markup=CANCEL_MARKUP)
    return NEWS_TITLE_KZ

async def news_title_kz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['n_title_kz'] = update.message.text
    await update.message.reply_text("🇷🇺 Шаг 3/5: Текст новости (RU):", reply_markup=CANCEL_MARKUP)
    return NEWS_TEXT_RU

async def news_text_ru(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['n_text_ru'] = update.message.text
    await update.message.reply_text("🇰🇿 Шаг 4/5: Текст новости (KZ):", reply_markup=CANCEL_MARKUP)
    return NEWS_TEXT_KZ

async def news_text_kz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['n_text_kz'] = update.message.text
    await update.message.reply_text(
        "📸 Шаг 5/5: Отправьте ФОТО.\n(Можно как фото или как файл). Или нажмите пропустить.", 
        reply_markup=PHOTO_MARKUP
    )
    return NEWS_PHOTO

# === ОБРАБОТКА ФОТО ===
async def news_photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo_file = None
    
    # 1. Если прислали сжатое фото
    if update.message.photo:
        photo_file = await update.message.photo[-1].get_file()
        
    # 2. Если прислали файл (Document) и это изображение
    elif update.message.document and 'image' in update.message.document.mime_type:
        photo_file = await update.message.document.get_file()
    
    # Если фото найдено - сохраняем
    if photo_file:
        file_name = f"news_{uuid.uuid4()}.jpg"
        save_path = os.path.join(UPLOADS_DIR, file_name)
        if not os.path.exists(UPLOADS_DIR): os.makedirs(UPLOADS_DIR)
        
        await photo_file.download_to_drive(save_path)
        photo_path = f"/uploads/{file_name}"
        await save_news(update, context, photo_path)
        return CHOOSING_ACTION
    
    # Если прислали ТЕКСТ (не кнопку пропуска), ругаемся
    await update.message.reply_text("⚠️ Пожалуйста, отправьте ФОТО или нажмите кнопку 'Пропустить'.")
    return NEWS_PHOTO

async def news_skip_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await save_news(update, context, None)
    return CHOOSING_ACTION

async def save_news(update, context, image_path):
    async with async_session() as session:
        new_news = News(
            title=context.user_data.get('n_title_ru', 'Без заголовка'),
            titleKz=context.user_data.get('n_title_kz', 'Без заголовка'),
            text=context.user_data.get('n_text_ru', ''),
            textKz=context.user_data.get('n_text_kz', ''),
            date=update.message.date.strftime("%d.%m.%Y"),
            image=image_path
        )
        session.add(new_news)
        await session.commit()
    
    await update.message.reply_text("✅ Новость опубликована!", reply_markup=MAIN_MENU_MARKUP)

# === ВИДЕО (ШАГИ) ===
async def video_title_ru(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['v_title_ru'] = update.message.text
    await update.message.reply_text("🇰🇿 Шаг 2/3: Название видео (KZ):", reply_markup=CANCEL_MARKUP)
    return VIDEO_TITLE_KZ

async def video_title_kz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['v_title_kz'] = update.message.text
    await update.message.reply_text("🔗 Шаг 3/3: Ссылка на YouTube:", reply_markup=CANCEL_MARKUP)
    return VIDEO_URL

async def video_finish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with async_session() as session:
        new_video = Video(
            title=context.user_data.get('v_title_ru'),
            titleKz=context.user_data.get('v_title_kz'),
            url=update.message.text
        )
        session.add(new_video)
        await session.commit()

    await update.message.reply_text("✅ Видео добавлено!", reply_markup=MAIN_MENU_MARKUP)
    return CHOOSING_ACTION

async def handle_schedule_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    document = update.message.document
    
    if not document.file_name.endswith('.xlsx'):
        await update.message.reply_text("⚠️ Нужен файл .xlsx")
        return WAITING_SCHEDULE

    file = await document.get_file()
    file_path = "temp_schedule.xlsx"
    await file.download_to_drive(file_path)
    
    try:
        # 1. Читаем файл полностью без заголовков сначала
        df_raw = pd.read_excel(file_path, header=None)

        # 2. Ищем строку, в которой есть слово "ФИО"
        header_row_index = -1
        for i, row in df_raw.iterrows():
            if row.astype(str).str.contains("ФИО").any():
                header_row_index = i
                break
        
        if header_row_index == -1:
            await update.message.reply_text("❌ В файле не найдена строка с заголовком 'ФИО'.")
            return WAITING_SCHEDULE

        # 3. Перечитываем файл, используя найденную строку как заголовок
        df = pd.read_excel(file_path, header=header_row_index)
        
        # Очищаем названия колонок от пробелов
        df.columns = df.columns.astype(str).str.strip()
        
        # Маппинг колонок
        rename_map = {
            'ФИО': 'name', 
            'Должность': 'role', 
            'Кабинет': 'cabinet',
            'Отделение': 'dept',
            'ПН': 'mon', 'ВТ': 'tue', 'СР': 'wed', 'ЧТ': 'thu', 'ПТ': 'fri'
        }
        df.rename(columns=rename_map, inplace=True)
        
        # Проверка наличия обязательных полей
        if 'name' not in df.columns:
            await update.message.reply_text("❌ Ошибка: не удалось распознать колонку 'ФИО'.")
            return WAITING_SCHEDULE

        # Убираем пустые строки и заменяем NaN
        df = df.dropna(subset=['name'])
        df = df.fillna("-").astype(str)
        
        # === НОВАЯ ЛОГИКА СОХРАНЕНИЯ В SQLITE ===
        async with async_session() as session:
            # 1. Удаляем старый график полностью
            await session.execute(delete(Schedule))
            
            # 2. Добавляем новых врачей
            count = 0
            for _, row in df.iterrows():
                doctor = Schedule(
                    name=str(row.get('name', '-')),
                    role=str(row.get('role', '-')),
                    cabinet=str(row.get('cabinet', '-')),
                    dept=str(row.get('dept', '-')),
                    mon=str(row.get('mon', '-')),
                    tue=str(row.get('tue', '-')),
                    wed=str(row.get('wed', '-')),
                    thu=str(row.get('thu', '-')),
                    fri=str(row.get('fri', '-'))
                )
                session.add(doctor)
                count += 1
            
            # 3. Фиксируем изменения
            await session.commit()
        
        await update.message.reply_text(
            f"✅ График обновлен!\nВрачей загружено: {count}", 
            reply_markup=MAIN_MENU_MARKUP
        )
        
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}")
    
    finally:
        # Удаляем временный файл
        if os.path.exists(file_path):
            os.remove(file_path)
            
    return CHOOSING_ACTION

# === ЛОГИКА ВАКАНСИЙ ===

async def start_vacancy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Показываем кнопку "Отмена" вместо удаления клавиатуры
    await update.message.reply_text(
        "💼 Введите название вакансии (например: Медсестра):", 
        reply_markup=CANCEL_MARKUP
    )
    return WAITING_VACANCY_TITLE

async def vacancy_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['vac_title'] = update.message.text
    await update.message.reply_text(
        "💰 Укажите зарплату (например: 200 000 тг или 'При собеседовании'):",
        reply_markup=CANCEL_MARKUP
    )
    return WAITING_VACANCY_SALARY

async def vacancy_salary(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['vac_salary'] = update.message.text
    await update.message.reply_text(
        "📝 Теперь напишите требования и описание вакансии:",
        reply_markup=CANCEL_MARKUP
    )
    return WAITING_VACANCY_TEXT

async def vacancy_finish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    
    async with async_session() as session:
        new_vac = Vacancy(
            title=context.user_data['vac_title'],
            salary=context.user_data['vac_salary'],
            text=text,
            date=update.message.date.strftime("%d.%m.%Y")
        )
        session.add(new_vac)
        await session.commit()

    # Возвращаем главное меню
    await update.message.reply_text("✅ Вакансия опубликована!", reply_markup=MAIN_MENU_MARKUP)
    return CHOOSING_ACTION

# Функция списка (аналогична новостям)
async def list_vacancies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with async_session() as session:
        result = await session.execute(select(Vacancy).order_by(Vacancy.id.desc()))
        items = result.scalars().all()

    if not items:
        await update.message.reply_text("📭 Вакансий нет.")
        return CHOOSING_ACTION

    await update.message.reply_text("💼 Актуальные вакансии:")
    for v in items:
        msg = f"🆔 {v.id}\n📌 {v.title}\n💰 {v.salary}\n📝 {v.text}"
        keyboard = [[InlineKeyboardButton("🗑 Удалить", callback_data=f"delete_vacancies_{v.id}")]]
        await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
    
    return CHOOSING_ACTION

# === СПИСКИ И КНОПКИ ===
async def show_list(update, category, title_ru):
    async with async_session() as session:
        model = None
        if category == "reviews": model = Review
        elif category == "news": model = News
        elif category == "videos": model = Video
        
        # Получаем последние 5
        result = await session.execute(select(model).order_by(model.id.desc()).limit(5))
        items = result.scalars().all()
        
    if not items:
        await update.message.reply_text("📭 Список пуст.")
        return
        
    await update.message.reply_text(f"📂 {title_ru} (последние 5):")
    for item in items:
        info = f"ID: {item.id}\n"
        if category == 'news': info += f"📰 {item.title}"
        elif category == 'videos': info += f"🎥 {item.title}"
        elif category == 'reviews': info += f"👤 {item.name}: {item.text}"
        
        # Важно: callback_data должен совпадать с логикой в callback_handler
        keyboard = [[InlineKeyboardButton("🗑 Удалить", callback_data=f"delete_{category}_{item.id}")]]
        await update.message.reply_text(info, reply_markup=InlineKeyboardMarkup(keyboard))

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split("_")
    action = parts[0]
    
    async with async_session() as session:
        if action == "approve":
            iid = int(parts[1])
            # ИСПОЛЬЗУЕМ sql_update ВМЕСТО update
            await session.execute(sql_update(Review).where(Review.id == iid).values(approved=True))
            await session.commit()
            await query.edit_message_text("✅ Одобрено.")
            
        elif action == "reject" or action == "delete":
            # Разбираем, что удаляем (review, news или video)
            cat = "reviews" if action == "reject" else parts[1]
            iid = int(parts[2]) if action == "delete" else int(parts[1])
            
            model = None
            if cat == "reviews": model = Review
            elif cat == "news": model = News
            elif cat == "videos": model = Video
            elif cat == "vacancies": model = Vacancy
            if model:
                await session.execute(delete(model).where(model.id == iid))
                await session.commit()
                msg = "❌ Отклонено." if action == "reject" else "🗑 Удалено."
                await query.edit_message_text(msg)

# === ЗАПУСК ===
if __name__ == "__main__":
    # УВЕЛИЧИВАЕМ ТАЙМАУТЫ, ЧТОБЫ ИЗБЕЖАТЬ ОШИБКИ ConnectTimeout
    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .read_timeout(30)
        .write_timeout(30)
        .connect_timeout(30)
        .pool_timeout(30)
        .build()
    )
    
    cancel_filter = filters.Regex("^❌ Отмена$")
    skip_filter = filters.Regex("^⏭ Пропустить фото$")

    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            # === ДОБАВЛЕНЫ ОБРАБОТЧИКИ КНОПОК МЕНЮ ===
            MessageHandler(filters.Regex("^💼 Вакансии"), start_vacancy),
            MessageHandler(filters.Regex("^📋 Список вакансий"), list_vacancies),
        ],
        states={
            CHOOSING_ACTION: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, choose_action)],
            
            WAITING_SCHEDULE: [
                MessageHandler(filters.Document.FileExtension("xlsx"), handle_schedule_upload),
                MessageHandler(cancel_filter, cancel)
            ],
            
            # --- НОВОСТИ ---
            NEWS_TITLE_RU: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, news_title_ru)],
            NEWS_TITLE_KZ: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, news_title_kz)],
            NEWS_TEXT_RU:  [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, news_text_ru)],
            NEWS_TEXT_KZ:  [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, news_text_kz)],
            
            NEWS_PHOTO: [
                MessageHandler(filters.PHOTO, news_photo_handler),
                MessageHandler(filters.Document.IMAGE, news_photo_handler), 
                MessageHandler(skip_filter, news_skip_photo),
                MessageHandler(filters.ALL & ~cancel_filter, news_photo_handler)
            ],
            
            # --- ВИДЕО ---
            VIDEO_TITLE_RU: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, video_title_ru)],
            VIDEO_TITLE_KZ: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, video_title_kz)],
            VIDEO_URL:      [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, video_finish)],

            # --- ВАКАНСИИ (УЖЕ БЫЛИ, ОСТАВЛЯЕМ) ---
            WAITING_VACANCY_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, vacancy_title)],
            WAITING_VACANCY_SALARY: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, vacancy_salary)],
            WAITING_VACANCY_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND & ~cancel_filter, vacancy_finish)],
        },
        fallbacks=[
            CommandHandler('cancel', cancel),
            MessageHandler(cancel_filter, cancel)
        ],
        allow_reentry=True
    )
    
    app.add_handler(conv_handler)
    app.add_handler(CallbackQueryHandler(callback_handler))
    
    print("Бот перезапущен с защитой от сбоев...")
    app.run_polling()